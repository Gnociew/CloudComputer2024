from api_request.knowledge_rag_api import query_text

def query_knowledge_base(query: str,knowledge_base_id: str) -> str:
    """查询知识库工具"""
    print(f"\n[Knowledge Base Tool] 查询: {query}")
    response = query_text(
        query=query,
        mode='global',
        only_need_context=False,
        only_need_prompt=False,
        knowledge_base_id=knowledge_base_id
    )
    if isinstance(response, dict) and 'message' in response:
        print("[Knowledge Base Tool] 找到相关信息")
        return response['message']
    print("[Knowledge Base Tool] 未找到相关信息")
    return "知识库中没有找到相关信息。"